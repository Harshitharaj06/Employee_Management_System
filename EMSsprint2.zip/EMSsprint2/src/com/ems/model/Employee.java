package com.ems.model;

import java.time.LocalDate;

public class Employee {
	String empId;
	String empName;
	LocalDate dob;
	float basicSalary;
	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	/**
	 * @return the empNamecontext.setAttribute("e", es.getEmployee(empid));	
	 */
	public String getEmpName() {
		return empName;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", dob=" + dob + ", basicSalary=" + basicSalary
				+ "]";
	}
	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	/**
	 * @return the dob
	 */
	public LocalDate getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	/**
	 * @return the basicSalary
	 */
	public float getBasicSalary() {
		return basicSalary;
	}
	/**
	 * @param basicSalary the basicSalary to set
	 */
	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}
	public Employee(String empId, String empName, LocalDate dob, float basicSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.dob = dob;
		this.basicSalary = basicSalary;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
}
