package com.ems.util;

public class InavlidDobException extends RuntimeException {
	
	public InavlidDobException(String msg)
	{
		super(msg);
	}

}
