package com.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.ems.model.Employee;

public class EmployeeDaoImplementation implements EmployeeDao {
Connection con;
	
	
	public String generateId(String empName) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean save(Employee emp) throws Exception{
		
		// TODO Auto-generated method stub
		con=getConnection();
		PreparedStatement ps=null;
		ps=con.prepareStatement("select * from Employee where empName=?");
		ps.setString(1, emp.getEmpName());
		ResultSet r1=ps.executeQuery();
		if(r1.next())
		{
			return false;
		}
		ps=con.prepareStatement("insert into Employee values(?,?,?,?)");
		ps.setString(1, emp.getEmpId());
		ps.setString(2,emp.getEmpName());
	    LocalDate dobRaw=emp.getDob();
	    //String strDate=dobRaw.getYear()+"-"+dobRaw.getMonthValue()+"-"+dobRaw.getDayOfMonth();
	    //ps.setString(3, strDate);
	    ps.setFloat(4, emp.getBasicSalary());
	    ps.setDate(3, new java.sql.Date(dobRaw.getYear()-1900,dobRaw.getMonthValue()-1,dobRaw.getDayOfMonth()));
	    
		int r= ps.executeUpdate();
		return r>0?true:false;
	}

	public boolean delete(String empId) throws Exception{
		con=getConnection();
		PreparedStatement ps=con.prepareStatement("delete from Employee where empId=?");
		ps.setString(1, empId);
		int r= ps.executeUpdate();
		return r>0?true:false;
		}

	public boolean update(Employee emp) throws Exception{
		con=getConnection();
		PreparedStatement ps=con.prepareStatement("update Employee set Salary=? where EmpId=?");
		ps.setFloat(1, emp.getBasicSalary());
		ps.setString(2, emp.getEmpId());
		int r=ps.executeUpdate();
		return r>0?true:false;
	}
		
	public Employee getEmployee(String empId) throws Exception {
		// TODO Auto-generated method stub
		con=getConnection();
		PreparedStatement ps=con.prepareStatement("Select * from Employee where empid=?");
		ps.setString(1, empId);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			java.sql.Date rowDate=rs.getDate(3);
			Employee emp=new Employee(rs.getString(1),rs.getString(2),
					                  rowDate.toLocalDate(),
					                  rs.getFloat(4));
		return emp;
		}
		
	return null;
	}
	
	public List<Employee> getAllEmployees() throws Exception{
		con=getConnection();
		List<Employee> empl=new ArrayList<>();
		//Employee emps=null;
		PreparedStatement ps=con.prepareStatement("select * from Employee");
		//String s="Select * from Employee";
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			java.sql.Date rowDate=rs.getDate(3);
			Employee emp=new Employee(rs.getString(1),rs.getString(2), rowDate.toLocalDate(),
	                  rs.getFloat(4));
		    empl.add(emp);
		}
		return empl;
	}
    public Connection getConnection()throws Exception
    {
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/ems","harshitha","harsh@123");
    	return con;
    }
}

