package com.deolite.ems.controller;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.model.Employee;
import com.ems.service.EmployeeServiceImp;

/**
 * Servlet implementation class GetEmployee
 */
@WebServlet({"/GetEmployee","/getemp"})
public class GetEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String empid=request.getParameter("empId");
		ServletContext context=getServletContext();
		EmployeeServiceImp es=new EmployeeServiceImp();
		Employee e;
		try
		{
			if(es.getEmployee(empid)!=null)
			    {
				context.setAttribute("e", es.getEmployee(empid));	
				context.setAttribute("Success","Employee Retrieved Successfully");
				}
				else
				{
					context.setAttribute("error","no such employee");
				}	
		}catch(Exception e1)
		{
			e1.printStackTrace();
		}
		
		
		response.sendRedirect("getemployee.jsp");
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
