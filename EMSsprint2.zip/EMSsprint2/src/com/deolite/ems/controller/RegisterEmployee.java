package com.deolite.ems.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.model.Employee;
import com.ems.service.EmployeeServiceImp;

/**
 * Servlet implementation class RegisteEmployee
 */
@WebServlet({"/RegisteEmployee","/register"})
public class RegisterEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("empName");
		String DOB=request.getParameter("dob");
		float salary=Float.parseFloat(request.getParameter("basicSalary"));
		
		Employee e=new Employee();
		e.setEmpName(name);
		e.setBasicSalary(salary);
		LocalDate localDate=LocalDate.parse(DOB, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		e.setDob(localDate);
		ServletContext context=getServletContext();
		EmployeeServiceImp es=new EmployeeServiceImp();
		try
		{
			String empId=es.generateId(e.getEmpName());
			e.setEmpId(empId);
		}
		catch(Exception e1)
		{
		e1.printStackTrace();
		}
		try
		{
		if(es.save(e))
		{
			context.setAttribute("Success","Employee added successfully");
		}
		else
		{
			context.setAttribute("error","user already exixts");
		}
	}
	catch(Exception ev)
		{
		ev.printStackTrace();
		}
		response.sendRedirect("addemployee.jsp");
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
