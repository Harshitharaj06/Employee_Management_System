package com.deolite.ems.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.model.Employee;
import com.ems.service.EmployeeServiceImp;

/**
 * Servlet implementation class ViewAllEmployee
 */
@WebServlet({"/ViewAllEmployee","/getAllemployee"})
public class ViewAllEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAllEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		EmployeeServiceImp es=new EmployeeServiceImp();
	try
	{
		List<Employee> l=es.getAllEmployees();
		if(l!=null)
		{
            System.out.println("hello");
			request.getSession().setAttribute("list", l);	
		}
		else
		{
			request.getSession().setAttribute("error","nodata");	
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	response.sendRedirect("getAllemployee.jsp");
	}

}
